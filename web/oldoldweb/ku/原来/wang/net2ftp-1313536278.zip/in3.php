<html>

<body>


<form action="in2.php" method="post">

things: <input type="text" name="things" />

time: <input type="text" name="time" />

<input type="submit" />

</form>


</body>

</html>