<?php
$con = mysql_connect("mysql13.000webhost.com","a8431291_in","wang0000");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("a8431291_in", $con);

$result = mysql_query("SELECT * FROM latest");
while($row = mysql_fetch_array($result))
  {
  echo $row['things'] . "  " . $row['time']."<br />";  
  }
mysql_close($con);
?>
