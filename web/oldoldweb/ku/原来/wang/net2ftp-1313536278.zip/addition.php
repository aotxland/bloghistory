<html>
<body>

<?php
function add($x,$y)
  {
   echo "x is ".$x."<br />";
   echo "y is ".$y."<br />";
  $total = $x + $y;
  return $total;

  }

echo add(1,16);
?>

</body>
</html>