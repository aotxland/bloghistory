<html> 

<head> 
  
<style> 

a:visited{color:#6699FF;text-decoration: none;}

a:link{color:#C0C0C0;text-decoration: none;}

a:hover{color:#6699FF;text-decoration: underline;
</style> 
<title>Latest</title>
 
</head>
 
<body>
 
<br/> 

<h3><div style="color:#C0C0C0">Things around recently :</div></h3> 

<br/> 
<blockquote> 
<div style="color:#6699FF">
 
<big> 

<?php include("in.php"); ?>


</big> 
</div> 
</blockquote> 
</br>
 
<hr/>
 
<h3> 
<blockquote>
<div style="color:#C0C0C0">More at my <a href="http://wp.oranlakes.site11.com/wp">&nbsp;>Wordpress<</a>&nbsp;&nbsp;&nbsp; Orlakes at gmail dot com&nbsp;&nbsp;&nbsp;&nbsp;</a>Last Update: 3/8/2011.</div></blockquote> 
</h3> 
</body> 
</html>
