<?php
$con = mysql_connect("mysql13.000webhost.com","a8431291_in","wang0000");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("a8431291_in", $con);

$sql="INSERT INTO latest (things, time)
VALUES
('$_POST[things]','$_POST[time]')";

if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
echo "1 record added";

mysql_close($con)
?>