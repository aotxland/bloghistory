<?php get_header();?>
	<main class="main-content">
	<div class="page404">
		<p>没找到任何内容。</p>
	</div>
	</main>
<?php get_footer();?>