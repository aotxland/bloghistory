    <footer class="site-footer u-textAlignCenter">
        Puma by <a href="https://fatesinger.com">bigfa</a>. <svg class="icon icon-heart" height="12" width="12" viewBox="0 0 12 12"><use xlink:href="<?php echo get_template_directory_uri() . '/static/img/svgdefs.svg';?>#icon-heart"></use></svg> Blog since 2015.
    </footer>
</div>
	<div class="back-to-top u-hide" onclick="backToTop();"><svg class="icon" height="32" width="32" viewBox="0 0 32 32"><use xlink:href="<?php echo get_template_directory_uri() . '/static/img/svgdefs.svg';?>#icon-arrow-up"></use></svg></div>
<?php wp_footer();?>
</body>
</html>